servo motor linear actuator by Mateon on Thingiverse: https://www.thingiverse.com/thing:6232193

Summary:
This is an linear actuator for 9g servo motors, commonly used in arduino projects. Made by Mateon (https://mateon.eu)
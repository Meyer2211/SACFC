Servo Door Mechanisms for Arduino Projects by maker_tutor on Thingiverse: https://www.thingiverse.com/thing:6494157

Summary:
https://youtu.be/NSfvkHuIsLY